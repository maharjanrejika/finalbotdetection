# -*- coding: utf-8 -*-
import pandas as pd
import pickle

#Importing dataset
dataset=pd.read_csv('data.csv')

#Creating Matrix of Dependent Variable
X=dataset.iloc[:, :-1].values

#Dependent Variable Vector
Y=dataset.iloc[:,-1].values

#Splitting dataset into Trainig set and Test set
from sklearn.model_selection import train_test_split
X_train,X_test,Y_train,Y_test=train_test_split(X,Y,train_size=0.9,random_state=0)


#Encoding Categorical data
from sklearn.preprocessing import LabelEncoder
labelencoder_X=LabelEncoder()

for i in range(0,56):
    X_train[:, i]=labelencoder_X.fit_transform(X_train[:, i].astype(str))
    X_test[:, i]=labelencoder_X.fit_transform(X_test[:, i].astype(str))

#Feature Scaling 
from sklearn.preprocessing import StandardScaler
sc_X=StandardScaler()
X_train=sc_X.fit_transform(X_train)
X_test=sc_X.transform(X_test)

#Fitting the SVM Classifier to the Training set
from sklearn.svm import SVC
classifier=SVC(kernel='rbf',random_state=0)
classifier.fit(X_train,Y_train)

#Predicting the test set result
Y_pred=classifier.predict(X_test)

#Creating the Confusion Matrix
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(Y_test,Y_pred)


#print(Y_test)
#print(Y_pred)
#print(cm)
#accuracy=(cm[0][0]+cm[1][1])/(cm[0][0]+cm[1][1]+cm[0][1]+cm[1][0])*100
#print(accuracy)



#######################################################################################################




from sklearn.metrics import classification_report,confusion_matrix
cm=confusion_matrix(Y_test,Y_pred)


print(confusion_matrix(Y_test,Y_pred))

print(classification_report(Y_test,Y_pred))

###############################################################################################################

from sklearn.metrics import accuracy_score

#print("KNN Accuracy: {0}".format(accuracy_score(Y_test, Y_pred)))

#a=matthews_corrcoef(Y_test, Y_pred)
#print("MCC: {0}".format(matthews_corrcoef(Y_test, Y_pred)))




from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, cohen_kappa_score

# Confusion matrix
confusion_matrix(Y_test, Y_pred)
Y_pred=classifier.predict(X_train)

#predictions = mlp.predict(X_train)
##
#classes = classes[unique_labels(y_true, y_pred)]


from sklearn.metrics import classification_report,confusion_matrix
cm=confusion_matrix(Y_train,Y_pred)

#cm1=confusion_matrix(Y_test, Y_pred, classes=class_names,
                      #title='Confusion matrix, without normalization')
#print(cm)
print(confusion_matrix(Y_train,Y_pred))

#print(classification_report(Y_test,predictions))

from sklearn.metrics import accuracy_score

print("KNN Classifier Accuracy for Training Set : {0}".format(accuracy_score(Y_train, Y_pred)))






#Make pickle file of our model
pickle.dump(classifier, open("model.pkl", "wb"))




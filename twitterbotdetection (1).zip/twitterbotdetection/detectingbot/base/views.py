from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def home(request):
    return render(request,'base/index.html')

def about(request):
    return render(request,'base/about.html')
    
def result(request):
    return HttpResponse(request, 'request')

def analyzedata(request):

    textinput = request.POST['search']
    text = [textinput]
    tweet_array = np.array(text)
    tweet_vector = vectorizer.transform(tweet_array)
    print(clf.predict(tweet_vector))
    results = clf.predict(tweet_vector)
    if results == 1:
        return render(request, 'not bot.html',{'textinput':textinput})
    elif results == -1:
        return render(request, 'botaccount.html',{'textinput':textinput})
    else:
        return HttpResponse('nth')
    